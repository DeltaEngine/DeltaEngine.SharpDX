using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: CLSCompliant(true)]
[assembly: AssemblyTitle("$projectname$")]
[assembly: AssemblyDescription("Delta Engine Game $projectname$")]
[assembly: AssemblyCompany("Delta Engine")]
[assembly: AssemblyCopyright("Copyright © Delta Engine 2013")]
[assembly: ComVisible(false)]
[assembly: Guid("$guid1$")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
