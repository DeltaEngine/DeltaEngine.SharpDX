namespace $safeprojectname$
{
	/// <summary>
	/// Loads Jewel$safeprojectname$ related content and settings
	/// </summary>
	public class Jewel$safeprojectname$Content : $safeprojectname$Content
	{
		public Jewel$safeprojectname$Content()
			: base("Jewel$safeprojectname$_") {}
	}
}