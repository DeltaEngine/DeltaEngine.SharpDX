namespace $safeprojectname$.Screens
{
	/*TODO
		/// <summary>
		/// The contents of this file are auto generated.
		///Do not edit the contents of this file, edits will possibly be lost
		/// </summary>
		public partial class Credits : BaseGameScreen
		{
			public Credits()
			{
					this.InitializeControls();
					this.Button0.Clicked += delegate
					{
						Close();
					};
			}
		}
	 */
}
