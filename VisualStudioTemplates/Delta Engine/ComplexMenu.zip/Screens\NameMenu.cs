namespace $safeprojectname$.Screens
{
	/*TODO
	public partial class NameMenu : BaseGameScreen
	{
		public NameMenu()
		{
				this.InitializeControls();
				this.BackButton.Clicked += delegate
				{
					Close();
				};
		}
	}
	 */
}