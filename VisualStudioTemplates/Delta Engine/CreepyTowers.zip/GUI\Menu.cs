using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DeltaEngine.Scenes;

namespace $safeprojectname$.GUI
{
	public abstract class Menu
	{
		public Scene scene;
	}
}