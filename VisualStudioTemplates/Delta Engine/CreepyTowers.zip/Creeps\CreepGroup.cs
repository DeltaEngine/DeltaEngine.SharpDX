using System.Collections.Generic;

namespace $safeprojectname$.Creeps
{
	public class CreepGroup
	{
		public List<CreepType> CreepList
		{
			get;
			set;
		}

		public float SpawnInterval
		{
			get;
			set;
		}
	}
}