namespace $safeprojectname$.Content
{
	public enum CreepStates
	{
		BurningMat,
		MeltMat,
		SlowMat,
		WetMat,
		FrozenMat
	}
}
