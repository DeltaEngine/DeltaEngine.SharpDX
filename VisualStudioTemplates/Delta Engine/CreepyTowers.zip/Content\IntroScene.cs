namespace $safeprojectname$.Content
{
	public enum IntroScene
	{
		StoryboardPanel,
		ComicStripsStoryboardPanel1Mat,
		ComicStripsStoryboardPanel2Mat,
		ComicStripsStoryboardPanel3Mat,
		ComicStripsStoryboardPanel4Mat,
		ComicStripsStoryboardPanel5Mat,
		ButtonIntroSkip,
		ButtonIntroFlipLeft,
		ButtonIntroFlipRight
	}
}