namespace $safeprojectname$.Content
{
	public enum SuccessScene
	{
		ButtonHome, 
		ButtonReplay,
		ButtonContinue,
		GoldCount, 
		GemCount,
		PlayerLevel, 
		AvatarLevel,
		PlayerName, 
		AvatarName,
		Star1,
		Star2,
		Star3,
		Star4,
		Star5
	}
}
