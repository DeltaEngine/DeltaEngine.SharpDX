namespace $safeprojectname$.Content
{
	public enum Settings
	{
		ButtonBack,
		MusicVolumeSlider,
		SoundVolumeSlider
	}
}
